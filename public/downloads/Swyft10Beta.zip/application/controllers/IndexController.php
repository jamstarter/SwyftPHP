<?php

class IndexController extends SwyftController{

	function index(){
		

	}
	


}