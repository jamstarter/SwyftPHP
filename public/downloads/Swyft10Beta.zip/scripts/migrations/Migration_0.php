<?php


class Migration_0 extends Swyft_DB{

	protected $_name = "test";

	public function up(){

	}
	
	public function down(){

	}

}