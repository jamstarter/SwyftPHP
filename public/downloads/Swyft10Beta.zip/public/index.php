<?php 
define("APPLICATION_PATH",dirname(dirname(__FILE__)));
require_once(APPLICATION_PATH."/library/Swyft/System/Bootstrap.php");

